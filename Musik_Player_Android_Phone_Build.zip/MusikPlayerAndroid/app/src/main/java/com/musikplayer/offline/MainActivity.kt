package com.musikplayer.offline

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

class MainActivity : ComponentActivity() {
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private var selectedName = "Belum ada lagu"

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "Lagu dipilih"
            controller?.apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                play()
            } ?: run {
                Toast.makeText(this, "Pemain sedang disiapkan, pilih lagu sekali lagi.", Toast.LENGTH_LONG).show()
            }
            status.text = selectedName
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                refresh()
            } catch (_: Exception) {
                status.text = "Gagal menghubungkan pemutar"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 50, 28, 28)
            setBackgroundColor(0xFF12121C.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply { this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER }
        layout.addView(label("♫  Musik Player", 28f))
        layout.addView(label("Pemutar musik offline • tetap berjalan di latar belakang", 13f, 0xFFB9B5C9.toInt()))
        status = label(selectedName, 19f)
        val statusParams = LinearLayout.LayoutParams(-1, 0, 1f)
        layout.addView(status, statusParams)
        val choose = Button(this).apply {
            text = "Pilih lagu dari HP"
            setOnClickListener { picker.launch(arrayOf("audio/*")) }
        }
        layout.addView(choose, LinearLayout.LayoutParams(-1, -2))
        playButton = Button(this).apply {
            text = "Putar / Jeda"
            setOnClickListener {
                controller?.let {
                    if (it.isPlaying) it.pause() else it.play()
                    refresh()
                } ?: Toast.makeText(this@MainActivity, "Tunggu sebentar sampai pemutar siap.", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(playButton, LinearLayout.LayoutParams(-1, -2))
        val stop = Button(this).apply {
            text = "Hentikan"
            setOnClickListener { controller?.stop(); status.text = "Pemutaran dihentikan" }
        }
        layout.addView(stop, LinearLayout.LayoutParams(-1, -2))
        layout.addView(label("Kontrol lagu juga muncul di notifikasi layar kunci.", 12f, 0xFFB9B5C9.toInt()))
        setContentView(layout)
    }

    private fun refresh() {
        val c = controller ?: return
        playButton.text = if (c.isPlaying) "Jeda" else "Putar"
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
