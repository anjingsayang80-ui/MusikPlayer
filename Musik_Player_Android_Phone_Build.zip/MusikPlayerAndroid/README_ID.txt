MUSIK PLAYER — PROYEK ANDROID

Fitur:
- Memilih satu file audio dari penyimpanan HP.
- Audio diputar menggunakan AndroidX Media3.
- MediaSessionService menjaga pemutaran saat aplikasi ditutup/layar dikunci.
- Kontrol media sistem/notifikasi dan layar kunci disediakan Android.

PENTING:
Ini adalah KODE SUMBER proyek Android, bukan APK siap pasang.
Untuk membuat APK:
1. Buka proyek ini di Android Studio pada komputer.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK debug akan dibuat di app/build/outputs/apk/debug/app-debug.apk

Catatan:
- Proyek menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35.
- Untuk menguji, gunakan Android Studio versi yang mendukung AGP 8.7.x dan SDK 35.
- Pemilihan audio memakai pemilih dokumen Android; tidak meminta akses seluruh file musik.
- Jika ponsel membatasi aplikasi latar belakang, izinkan Musik Player berjalan di latar belakang / tanpa optimasi baterai.

CARA MEMBUAT APK HANYA DENGAN HP:
1. Masuk ke github.com lewat Chrome dan login/buat akun.
2. Buat repository baru bernama MusikPlayer, pilih Public atau Private.
3. Ekstrak ZIP ini memakai aplikasi pengelola file.
4. Di halaman repository, gunakan Add file > Upload files. Unggah isi folder MusikPlayer (termasuk folder .github jika terlihat). Jika sulit mengunggah folder tersembunyi .github dari HP, buat workflow secara manual di GitHub dengan path .github/workflows/build-apk.yml dan isi file build-apk.yml seperti di dalam ZIP.
5. Commit perubahan ke branch main.
6. Buka tab Actions, pilih workflow Build Musik Player APK, tekan Run workflow.
7. Setelah selesai hijau, buka hasil run dan unduh artifact Musik-Player-debug-APK.zip. Ekstrak, lalu pasang app-debug.apk.

Catatan: Proses build dilakukan oleh GitHub di cloud; HP hanya dipakai untuk mengunggah dan mengunduh. Jangan bagikan password atau kode login GitHub kepada siapa pun.
